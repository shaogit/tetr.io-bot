"""
缓存模块
提供缓存管理功能
"""
from .manager import CacheManager

__all__ = ['CacheManager']
