# TETR.IO AstrBot 插件设计文档

## 一、项目概述

### 1.1 项目背景
基于 TETR.IO 官方 TETRA CHANNEL API 开发的 AstrBot 聊天机器人插件，为用户提供便捷的 TETR.IO 游戏数据查询服务。插件设计参考 ch.tetr.io 网站的视觉风格，提供美观的数据展示界面。

### 1.2 核心目标
- 实现完整的 TETR.IO 用户数据查询功能
- 提供类似 ch.tetr.io 的视觉风格和用户体验
- 支持多种查询模式（用户信息、排行榜、统计数据等）
- 优化数据展示，适配聊天场景

### 1.3 技术栈约束
- 开发框架：AstrBot Plugin API
- 编程语言：Python 3.8+
- HTTP 客户端：aiohttp（异步请求）
- 图像渲染：PIL/Pillow（生成数据卡片）
- 数据源：TETRA CHANNEL REST API (https://ch.tetr.io/api/)

## 二、功能需求设计

### 2.1 核心功能模块

#### 模块一：用户信息查询
**功能描述**：查询指定用户的完整资料信息

**触发指令**：
- `/tetr user <username>` - 查询用户完整信息
- `/tetr u <username>` - 简化指令

**数据内容**：
| 数据项 | 说明 | 数据来源 |
|--------|------|---------|
| 基础信息 | 用户名、用户ID、角色、注册时间 | API `/users/:user` |
| 徽章系统 | 用户获得的所有徽章及说明 | badges 字段 |
| 统计数据 | XP、游戏时长、在线游戏场次、胜场 | xp, gametime, gamesplayed, gameswon |
| 国家/地区 | 国旗标识 | country 字段 |
| 支持者状态 | 是否为支持者及等级 | supporter, supporter_tier |
| 社交连接 | Discord、Twitch、Twitter等 | connections 对象 |
| 个人简介 | About Me 区域 | bio 字段 |
| 成就评分 | AR值及成就分布统计 | ar, ar_counts |

**视觉呈现**：
- 顶部：头像 + 横幅（如果有）
- 左侧：用户名、徽章、基础信息
- 右侧：统计数据卡片
- 底部：个人简介、社交连接

---

#### 模块二：游戏模式数据查询
**功能描述**：查询用户在各游戏模式中的记录和排名

**触发指令**：
- `/tetr league <username>` - TETRA LEAGUE 数据
- `/tetr 40l <username>` - 40 LINES 数据
- `/tetr blitz <username>` - BLITZ 数据
- `/tetr qp <username>` - QUICK PLAY 数据
- `/tetr zen <username>` - ZEN 模式数据

**数据结构**：

##### TETRA LEAGUE（竞技联赛）
| 数据项 | 说明 |
|--------|------|
| 段位信息 | 当前段位、段位图标、段位颜色 |
| TR 值 | Tetra Rating（竞技分数）|
| 排名 | 全球排名、百分位排名 |
| 赛季最高 | 历史最高段位 |
| 核心数据 | APM（每分钟攻击）、PPS（每秒方块）、VS（VS 分数）|
| 战绩统计 | 胜场、败场、胜率 |
| 进阶数据 | GLICKO、RD（评分偏差）|

##### 40 LINES（40行冲刺）
| 数据项 | 说明 |
|--------|------|
| 最佳时间 | 完成时间（秒）|
| 全球排名 | 全球/本地排名 |
| 方块数 | 使用方块数量 |
| PPS | 每秒方块数 |
| Finesse | 操作精准度（百分比）|
| KPP | 每方块按键数 |
| KPS | 每秒按键数 |

##### BLITZ（闪电战）
| 数据项 | 说明 |
|--------|------|
| 最高分数 | 最高得分 |
| 全球排名 | 全球/本地排名 |
| 方块数 | 放置方块数 |
| PPS | 每秒方块数 |
| SPP | 每方块得分 |
| 等级 | 达到等级 |
| 特殊技巧 | Quads、T-Spins、All Clears |

##### QUICK PLAY（快速游戏）
| 数据项 | 说明 |
|--------|------|
| 本周记录 | 当前周期成绩 |
| 历史最佳 | 生涯最佳成绩及排名 |
| 楼层进度 | 到达楼层数 |

**视觉呈现策略**：
- 使用渐变色背景区分不同游戏模式
- 段位显示使用对应的段位颜色主题
- 关键数据使用大字体突出显示
- 次要数据使用表格形式整齐排列

---

#### 模块三：排行榜查询
**功能描述**：查询各游戏模式的全球/本地排行榜

**触发指令**：
- `/tetr leaderboard <mode> [limit]` - 查询排行榜
- `/tetr lb <mode> [limit]` - 简化指令

**支持模式**：
| 模式标识 | 说明 | API 端点 |
|---------|------|----------|
| league | TETRA LEAGUE 排行榜 | `/users/by/league` |
| 40l | 40 LINES 排行榜 | `/users/by/40l` |
| blitz | BLITZ 排行榜 | `/users/by/blitz` |
| xp | XP 排行榜 | `/users/by/xp` |
| ar | 成就评分排行榜 | `/users/by/ar` |

**展示内容**：
- 默认显示前 10 名
- 可选参数：限制条数（最多 25 条）
- 每条包含：排名、用户名、关键数据、国家标识

**数据表格结构**：
```
排名 | 用户名 | 段位/成绩 | 国家 | TR/Time/Score
-----|--------|-----------|------|---------------
#1   | Player1| X+ 25000  | 🇺🇸  | 25000.00
#2   | Player2| U  24500  | 🇯🇵  | 24500.00
...
```

---

#### 模块四：服务器统计查询
**功能描述**：查询 TETR.IO 服务器全局统计数据

**触发指令**：
- `/tetr stats` - 服务器统计
- `/tetr server` - 服务器信息

**数据内容**：
| 统计项 | 说明 | 字段名 |
|--------|------|--------|
| 总玩家数 | 包含匿名账户 | usercount |
| 注册用户 | 实名注册用户数 | totalaccounts |
| 匿名用户 | 匿名账户数 | anoncount |
| 排位用户 | 有排名的用户 | rankedcount |
| 游戏记录 | 保存的游戏记录数 | recordcount |
| 总游戏场次 | 所有游戏场次 | gamesplayed |
| 完成场次 | 完成的游戏 | gamesfinished |
| 总游戏时长 | 累计游戏时间 | gametime |
| 方块放置数 | 总方块数 | piecesplaced |
| 总按键数 | 累计按键数 | inputs |
| 增长速度 | 用户/游戏增长率 | usercount_delta, gamesplayed_delta |

**视觉呈现**：
- 使用多列卡片布局
- 大数字 + 标签形式
- 增长数据使用箭头和颜色标识

---

#### 模块五：用户搜索功能
**功能描述**：模糊搜索用户名

**触发指令**：
- `/tetr search <keyword>` - 搜索用户
- `/tetr find <keyword>` - 搜索别名

**搜索逻辑**：
- 调用 API `/users/search/:query`
- 返回匹配的用户列表（最多显示 10 个）
- 显示用户名、段位、XP等关键信息

---

#### 模块六：成就系统查询
**功能描述**：查询用户成就及成就排行榜

**触发指令**：
- `/tetr achievements <username>` - 用户成就
- `/tetr ach <username>` - 简化指令

**展示内容**：
- 已获得成就列表
- 成就等级（Bronze、Silver、Gold、Platinum、Diamond）
- 成就获得时间
- 成就完成度统计

### 2.2 辅助功能模块

#### 功能一：数据对比
**功能描述**：对比两个用户的数据

**触发指令**：
- `/tetr compare <user1> <user2>` - 对比两个用户

**对比维度**：
- TETRA LEAGUE 数据对比
- 各模式最佳成绩对比
- 统计数据对比

#### 功能二：帮助文档
**功能描述**：显示插件使用帮助

**触发指令**：
- `/tetr help` - 显示帮助
- `/tetr` - 无参数时显示帮助

**帮助内容**：
- 所有可用指令列表
- 指令使用示例
- 常见问题解答

#### 功能三：数据趋势（可选）
**功能描述**：查看用户数据变化趋势

**触发指令**：
- `/tetr trend <username> <mode>` - 数据趋势图

**数据来源**：
- 使用 Labs API `/labs/leagueflow/:user`
- 生成 TR、排名变化趋势图

## 三、视觉设计规范

### 3.1 色彩系统
参考 ch.tetr.io 网站的配色方案：

#### 主色调
| 颜色名称 | HEX 值 | 使用场景 |
|---------|--------|---------|
| 主背景色 | #0F0F14 | 卡片主背景 |
| 次级背景 | #1A1A24 | 分区背景 |
| 边框色 | #2A2A35 | 分割线、边框 |
| 主文本色 | #FFFFFF | 主要文字 |
| 次文本色 | #9B9BA5 | 次要信息 |
| 强调色 | #6366F1 | 按钮、链接 |

#### 段位配色
| 段位 | 颜色 | HEX |
|------|------|-----|
| X Rank | 紫色渐变 | #A855F7 → #8B5CF6 |
| U Rank | 红紫渐变 | #EC4899 → #A855F7 |
| SS Rank | 红色 | #EF4444 |
| S+ Rank | 橙红 | #F97316 |
| S Rank | 橙色 | #F59E0B |
| A+ ~ D | 绿→蓝渐变 | #10B981 → #3B82F6 |

#### 游戏模式主题色
| 模式 | 主题色 | HEX |
|------|--------|-----|
| TETRA LEAGUE | 紫色 | #8B5CF6 |
| 40 LINES | 蓝色 | #3B82F6 |
| BLITZ | 红色 | #EF4444 |
| QUICK PLAY | 青色 | #06B6D4 |
| ZEN | 绿色 | #10B981 |

#### 渐变效果
| 渐变类型 | 配色方案 | 应用场景 |
|---------|---------|----------|
| 深色光泽渐变 | #1A1A24 → #0F0F14 (135deg) | 卡片背景 |
| 紫色光晕 | #6366F1 (0%) → transparent (100%) | 段位高光 |
| 霓虹渐变 | #A855F7 → #6366F1 → #3B82F6 | X/U 段位背景 |
| 暗金渐变 | #F59E0B → #D97706 | 成就徽章 |
| 赛博蓝 | #06B6D4 → #0891B2 | 数据统计区 |

### 3.2 布局设计规范

#### 用户信息卡片布局
```
┌─────────────────────────────────────────────┐
│  [Banner Background]                        │
│  ┌─────┐                                    │
│  │Avatar│  USERNAME                         │
│  │     │  [Badges Row]                      │
│  └─────┘  Role • Country Flag               │
├─────────────────────────────────────────────┤
│  📊 统计数据                                │
│  ┌──────────┬──────────┬──────────┐         │
│  │ XP       │ 游戏时长  │ 在线游戏 │         │
│  │ 12,345   │ 123h     │ 456      │         │
│  └──────────┴──────────┴──────────┘         │
├─────────────────────────────────────────────┤
│  🎮 TETRA LEAGUE                            │
│  ┌─────────────────────────────────┐        │
│  │ [Rank Icon] S+ Rank             │        │
│  │ TR: 21,234.56  (#1234 全球)     │        │
│  │ APM: 65.4  PPS: 1.2  VS: 78.9  │        │
│  └─────────────────────────────────┘        │
├─────────────────────────────────────────────┤
│  🏁 40 LINES                                │
│  ┌─────────────────────────────────┐        │
│  │ ⏱ 32.45s  (#567 全球)           │        │
│  │ PPS: 2.5  Finesse: 95.2%        │        │
│  └─────────────────────────────────┘        │
└─────────────────────────────────────────────┘
```

#### 排行榜卡片布局
```
┌─────────────────────────────────────────────┐
│  🏆 TETRA LEAGUE 排行榜                     │
│  更新时间: 2024-01-01 12:00                 │
├─────────────────────────────────────────────┤
│  #  用户名        段位      TR       国家   │
├─────────────────────────────────────────────┤
│  1  PlayerOne    X 25000   25000.0  🇺🇸    │
│  2  PlayerTwo    U 24500   24500.0  🇯🇵    │
│  3  PlayerThree  U 24000   24000.0  🇨🇳    │
│  ...                                        │
│  10 PlayerTen    SS 22000  22000.0  🇰🇷    │
└─────────────────────────────────────────────┘
```

### 3.3 图标和徽章系统

#### 徽章显示规则
- 徽章按组（group）分组显示
- 每个徽章显示为小图标 + hover 提示信息
- 最多显示一行，超出部分折叠

#### 段位图标
- 使用文字 + 背景色块表示段位
- 高段位使用渐变背景
- 显示格式：`[段位字母] 段位名称 TR值`

### 3.5 背景素材设计

#### 背景素材获取策略

**素材来源清单**：
| 素材类型 | 推荐来源 | 用途 | 许可证要求 |
|---------|---------|------|------------|
| 科技纹理 | Unsplash, Pexels | 卡片背景层 | 免费商用 |
| 几何图案 | Subtle Patterns | 微妙纹理 | CC0 |
| 抽象渐变 | 自行生成 | 动态背景 | - |
| 方块图案 | 自绘矢量 | TETR.IO 主题 | - |
| 光效素材 | Pixabay | 光晕、光线 | 免费 |
| 赛博朋克风格 | Freepik (免费版) | 未来科技感 | 归属标注 |

**具体素材网站**：
- Unsplash (https://unsplash.com) - 关键词: "abstract dark", "technology", "geometric"
- Pexels (https://pexels.com) - 关键词: "dark background", "neon", "digital"
- Subtle Patterns (https://subtlepatterns.com) - 低调纹理
- Pixabay (https://pixabay.com) - 关键词: "light effect", "glow"
- Carbon Fiber Textures - 碳纤维纹理（科技感）

#### 背景层次设计

**多层叠加架构**：
```
第1层（最底）：深色纹理基底
  ↓ 透明度混合
第2层：抽象几何图案（低透明度 10-20%）
  ↓ 叠加模式
第3层：渐变色遮罩（根据段位/模式变色）
  ↓ 正片叠底
第4层：光效点缀（边缘光、光晕）
  ↓ 滤色模式
第5层：内容区半透明蒙版
  ↓ 正常模式
最终：文字和数据内容
```

#### 不同卡片类型的背景方案

##### 用户信息卡背景
| 元素 | 设计方案 |
|------|----------|
| 基底纹理 | 深色碳纤维纹理 / 六角形科技网格 |
| 动态元素 | 根据用户段位使用对应颜色的渐变光晕 |
| 横幅区域 | 用户自定义横幅 or 默认抽象渐变 |
| 头像装饰 | 发光边框（段位色）+ 阴影 |
| 特效 | 边缘微光效果、角落装饰性线条 |

##### TETRA LEAGUE 卡片背景
| 元素 | 设计方案 |
|------|----------|
| 主题色 | 紫色系渐变 (#8B5CF6 → #6366F1) |
| 纹理 | 方块网格图案（低透明度）|
| 段位区 | 段位对应颜色的强烈渐变 + 发光效果 |
| 装饰 | 对战剑交叉图标（水印式）|
| 数据区 | 半透明深色卡片叠加 |

##### 40 LINES 卡片背景
| 元素 | 设计方案 |
|------|----------|
| 主题色 | 蓝色系渐变 (#3B82F6 → #2563EB) |
| 纹理 | 速度线条、计时器图案 |
| 特效 | 光速冲刺感的拖尾效果 |
| 装饰 | 倒计时表盘元素 |

##### BLITZ 卡片背景
| 元素 | 设计方案 |
|------|----------|
| 主题色 | 红色系渐变 (#EF4444 → #DC2626) |
| 纹理 | 爆炸能量纹理、闪电图案 |
| 特效 | 能量波纹、火花效果 |
| 装饰 | 得分爆炸星芒 |

##### 排行榜卡片背景
| 元素 | 设计方案 |
|------|----------|
| 主题色 | 金色-紫色渐变（奖杯感）|
| 纹理 | 排名梯度条纹 |
| 特效 | 冠军光芒（前三名）|
| 装饰 | 奖杯、星星、皇冠图标 |

#### 动态背景生成逻辑

**程序化生成策略**：

1. **渐变背景生成器**
   - 输入：主题色、方向角度
   - 输出：双色/三色渐变图层
   - 算法：线性渐变 + 噪点叠加

2. **几何图案生成器**
   - 六角形网格（蜂巢状）
   - 方块网格（TETR.IO 主题）
   - 点阵图案
   - 参数：密度、透明度、颜色

3. **光效生成器**
   - 径向光晕（中心发光）
   - 边缘光（卡片边框光效）
   - 聚光灯效果
   - 霓虹描边

4. **粒子装饰生成器**
   - 星星点点（成就、高分）
   - 方块漂浮（TETR.IO 元素）
   - 能量粒子

#### 背景缓存和优化

**缓存策略**：
```
assets/backgrounds/
├── base/                    # 基础纹理（静态）
│   ├── carbon_fiber.png
│   ├── hexagon_grid.png
│   ├── tech_lines.png
│   └── subtle_noise.png
├── gradients/               # 预生成渐变
│   ├── x_rank.png
│   ├── u_rank.png
│   ├── ss_rank.png
│   └── ...
├── effects/                 # 光效素材
│   ├── glow_radial.png
│   ├── edge_light.png
│   └── spark.png
└── composed/                # 合成缓存（运行时）
    ├── user_card_x.png
    └── league_card_purple.png
```

**优化措施**：
- 基础纹理一次性加载到内存
- 渐变背景预生成并缓存
- 相同配置的背景复用
- 使用 WebP 格式减少存储

### 3.4 字体规范

#### 字体选择
| 内容类型 | 字体 | 字号 |
|---------|------|------|
| 主标题 | 黑体/粗体 | 24-28px |
| 次标题 | 中等粗细 | 18-20px |
| 正文 | 常规 | 14-16px |
| 数据 | 等宽字体 | 16-20px |
| 小字注释 | 常规 | 12px |

#### 文字样式
- 用户名：粗体
- 数据值：等宽字体（模拟数字显示器效果）
- 标签：全大写或小型大写字母

## 四、技术架构设计

### 4.1 系统架构

#### 整体架构图
```mermaid
graph TB
    User[用户输入指令] --> Parser[指令解析器]
    Parser --> Router[指令路由器]
    
    Router --> UserQuery[用户查询服务]
    Router --> LeaderboardQuery[排行榜查询服务]
    Router --> StatsQuery[统计查询服务]
    Router --> SearchService[搜索服务]
    
    UserQuery --> APIClient[API 客户端]
    LeaderboardQuery --> APIClient
    StatsQuery --> APIClient
    SearchService --> APIClient
    
    APIClient --> Cache[缓存管理器]
    Cache --> Redis[(Redis缓存)]
    Cache --> Memory[(内存缓存)]
    
    APIClient --> HTTP[HTTP 请求处理]
    HTTP --> TETRAPI[TETR.IO API]
    
    UserQuery --> Renderer[图像渲染器]
    LeaderboardQuery --> Renderer
    StatsQuery --> Renderer
    
    Renderer --> ImageGen[PIL 图像生成]
    ImageGen --> Result[消息结果]
    
    Result --> AstrBot[AstrBot 消息系统]
    AstrBot --> Platform[消息平台]
```

### 4.2 核心组件设计

#### 组件一：API 客户端（APIClient）

**职责**：
- 封装所有 TETR.IO API 调用
- 统一处理请求头（X-Session-ID）
- 实现请求重试机制
- 错误处理和日志记录

**接口设计**：
| 方法名 | 参数 | 返回值 | 说明 |
|--------|------|--------|------|
| get_user_info | username: str | UserInfo对象 | 获取用户信息 |
| get_user_summary | username: str, mode: str | SummaryInfo对象 | 获取模式摘要 |
| get_leaderboard | mode: str, limit: int | List[LeaderboardEntry] | 获取排行榜 |
| get_server_stats | 无 | ServerStats对象 | 获取服务器统计 |
| search_user | query: str | List[UserInfo] | 搜索用户 |

**请求配置**：
- User-Agent: "AstrBot-TETRIO-Plugin/1.0"
- X-Session-ID: 生成唯一会话标识
- 超时时间: 10 秒
- 重试次数: 3 次（指数退避）

---

#### 组件二：缓存管理器（CacheManager）

**职责**：
- 实现多级缓存策略
- 遵循 API 响应的缓存时间建议
- 减少 API 请求频率

**缓存策略**：
| 数据类型 | 缓存时长 | 存储位置 | 理由 |
|---------|---------|---------|------|
| 用户基础信息 | 5 分钟 | 内存 | API 建议，数据较稳定 |
| 游戏模式数据 | 5 分钟 | 内存 | API 建议，记录可能更新 |
| 排行榜数据 | 10 分钟 | 内存 | 排名变化较慢 |
| 服务器统计 | 1 分钟 | 内存 | 数据变化快，但查询频率低 |
| 用户头像/横幅 | 24 小时 | 文件系统 | 图片资源，较少变化 |

**缓存键设计**：
- 用户信息: `tetr:user:{username}`
- 模式数据: `tetr:summary:{username}:{mode}`
- 排行榜: `tetr:lb:{mode}:{limit}`
- 服务器统计: `tetr:stats:server`

**缓存失效机制**：
- 基于 TTL 自动过期
- 支持手动刷新（管理员指令）
- 监听 API 响应的 cache 字段

---

#### 组件三：图像渲染器（ImageRenderer）

**职责**：
- 将数据转换为美观的图片
- 实现 ch.tetr.io 风格的视觉设计
- 支持多种卡片类型渲染
- 管理背景素材和视觉效果

**渲染流程**：
```mermaid
flowchart LR
    Data[数据对象] --> Template[选择模板]
    Template --> Layout[布局计算]
    Layout --> Draw[绘制元素]
    Draw --> Background[背景层]
    Draw --> Content[内容层]
    Draw --> Decoration[装饰层]
    Background --> Composite[图层合成]
    Content --> Composite
    Decoration --> Composite
    Composite --> Export[导出图片]
    Export --> Result[Base64/文件]
```

**模板类型**：
| 模板名称 | 适用场景 | 尺寸（像素）|
|---------|---------|------------|
| UserProfile | 用户完整信息 | 800 x 1200 |
| ModeCard | 单个游戏模式数据 | 800 x 400 |
| Leaderboard | 排行榜列表 | 800 x 600 |
| ServerStats | 服务器统计 | 800 x 500 |
| CompareView | 用户对比 | 1000 x 800 |

**绘制元素**：
- 背景：渐变色、纹理、透明度
- 文字：多字体、颜色、对齐、阴影
- 图标：Emoji、自定义图标、段位标识
- 图表：条形图、折线图、饼图（数据可视化）
- 分割线：实线、虚线、渐变线

**资源管理**：
- 字体文件：存储在 `assets/fonts/` 目录
- 图标资源：存储在 `assets/icons/` 目录
- 背景素材：存储在 `assets/backgrounds/` 目录
- 模板配置：JSON 格式，定义布局和样式

**高级视觉效果实现**：

##### 渐变和混合模式
| 效果 | 实现方式 | 应用场景 |
|------|---------|----------|
| 线性渐变 | PIL ImageDraw + 逐像素计算 | 背景、按钮 |
| 径向渐变 | 距离场算法 | 光晕、聚光 |
| 透明度渐变 | Alpha 通道渐变 | 边缘淡出 |
| 正片叠底 | PIL Image.blend() | 纹理叠加 |
| 滤色模式 | 自定义混合算法 | 光效 |

##### 光效和阴影
| 效果 | 实现技术 | 参数 |
|------|---------|------|
| 外发光 | 高斯模糊 + 透明度 | 半径: 10-30px, 颜色: 主题色 |
| 内阴影 | 反向阴影算法 | 偏移: 2px, 模糊: 5px |
| 文字阴影 | PIL 多层绘制 | X/Y 偏移: 2px, 颜色: #000000 50% |
| 边缘光 | 描边 + 模糊 | 宽度: 2px, 发光色 |
| 霓虹效果 | 多层发光叠加 | 3层渐进模糊 |

##### 纹理和图案
| 纹理类型 | 生成方法 | 参数控制 |
|---------|---------|----------|
| 噪点纹理 | Perlin Noise 算法 | 密度、强度 |
| 六角网格 | 几何算法绘制 | 大小、间距、线宽 |
| 方块网格 | 规则矩形阵列 | 方块大小、间隔 |
| 碳纤维 | 斜线交织图案 | 角度、密度 |
| 光栅扫描线 | 水平条纹 | 间距、透明度 |

##### 装饰元素
| 元素 | 设计方案 | 位置 |
|------|---------|------|
| 角落装饰 | 科技感线条、L 形框 | 四角 |
| 边框光效 | 渐变描边 + 发光 | 卡片边缘 |
| 水印图案 | 大尺寸低透明度图标 | 背景中央 |
| 数据光标 | 竖线 + 光点 | 数据旁 |
| 徽章光芒 | 放射状光线 | 徽章周围 |

##### 排版增强
| 技术 | 效果 | 实现 |
|------|------|------|
| 文字描边 | 清晰度提升 | 多次绘制偏移 |
| 渐变文字 | 彩色文字 | 渐变图层 + 蒙版 |
| 发光文字 | 强调重点 | 文字 + 外发光 |
| 数字等宽 | 整齐美观 | 等宽字体 + 对齐 |
| 文字倾斜 | 动态感 | 旋转变换 |

---

#### 组件四：指令路由器（CommandRouter）

**职责**：
- 解析用户指令
- 路由到对应的处理函数
- 参数验证和错误处理

**指令树结构**：
```
/tetr
├── user <username>          # 用户信息
├── u <username>             # 简化指令
├── league <username>        # TETRA LEAGUE
├── 40l <username>           # 40 LINES
├── blitz <username>         # BLITZ
├── qp <username>            # QUICK PLAY
├── zen <username>           # ZEN
├── leaderboard <mode> [n]   # 排行榜
├── lb <mode> [n]            # 排行榜简化
├── stats                    # 服务器统计
├── search <keyword>         # 搜索用户
├── compare <u1> <u2>        # 对比用户
├── achievements <username>  # 成就
├── ach <username>           # 成就简化
├── trend <username> <mode>  # 数据趋势
└── help                     # 帮助文档
```

**参数验证规则**：
| 参数类型 | 验证规则 | 错误提示 |
|---------|---------|---------|
| username | 3-16字符，字母数字下划线 | "用户名格式错误" |
| mode | 枚举值（league/40l/blitz等）| "不支持的游戏模式" |
| limit | 1-25 的整数 | "排行榜条数应在1-25之间" |

---

#### 组件五：数据模型层（DataModels）

**职责**：
- 定义数据结构
- 实现数据验证
- 提供数据转换方法

**核心数据模型**：

##### UserInfo（用户信息）
| 字段名 | 类型 | 说明 |
|--------|------|------|
| user_id | str | 用户 ID |
| username | str | 用户名 |
| role | str | 角色（user/bot/admin等）|
| country | str | 国家代码 |
| xp | float | 经验值 |
| gametime | float | 游戏时长（秒）|
| gamesplayed | int | 游戏场次 |
| gameswon | int | 胜场 |
| badges | List[Badge] | 徽章列表 |
| supporter | bool | 是否支持者 |
| bio | str | 个人简介 |
| connections | Dict | 社交连接 |

##### LeagueData（TETRA LEAGUE 数据）
| 字段名 | 类型 | 说明 |
|--------|------|------|
| rank | str | 段位（x/u/ss/s+/s/a+...）|
| tr | float | Tetra Rating |
| glicko | float | Glicko 评分 |
| rd | float | 评分偏差 |
| apm | float | APM |
| pps | float | PPS |
| vs | float | VS Score |
| wins | int | 胜场 |
| losses | int | 败场 |
| percentile | float | 百分位排名 |
| global_rank | int | 全球排名 |

##### RecordData（记录数据）
| 字段名 | 类型 | 说明 |
|--------|------|------|
| mode | str | 游戏模式 |
| value | float | 主要成绩（时间/分数）|
| rank | int | 全球排名 |
| local_rank | int | 本地排名 |
| pieces | int | 方块数 |
| pps | float | PPS |
| finesse | float | 精准度 |
| timestamp | datetime | 记录时间 |

### 4.3 数据流设计

#### 用户查询流程
```mermaid
sequenceDiagram
    participant U as 用户
    participant B as AstrBot
    participant P as 插件
    participant R as 路由器
    participant C as 缓存
    participant A as API客户端
    participant T as TETR.IO API
    participant I as 图像渲染器
    
    U->>B: /tetr user folx
    B->>P: 触发指令事件
    P->>R: 解析指令
    R->>C: 检查缓存
    
    alt 缓存命中
        C-->>R: 返回缓存数据
    else 缓存未命中
        R->>A: 请求 API
        A->>T: GET /users/folx
        T-->>A: 返回用户数据
        A->>C: 存入缓存
        A-->>R: 返回数据
    end
    
    R->>I: 传递数据进行渲染
    I->>I: 生成用户信息卡片
    I-->>R: 返回图片
    R-->>P: 返回结果
    P->>B: 发送消息（图片）
    B->>U: 显示用户信息卡片
```

#### 排行榜查询流程
```mermaid
sequenceDiagram
    participant U as 用户
    participant P as 插件
    participant R as 路由器
    participant C as 缓存
    participant A as API客户端
    participant I as 渲染器
    
    U->>P: /tetr lb league 10
    P->>R: 路由到排行榜查询
    R->>C: 查询缓存 tetr:lb:league:10
    
    alt 缓存有效
        C-->>R: 返回排行榜数据
    else 缓存过期
        R->>A: 调用 API
        A-->>R: 返回数据
        R->>C: 更新缓存（TTL: 10分钟）
    end
    
    R->>I: 渲染排行榜图片
    I-->>R: 返回图片
    R-->>U: 发送排行榜卡片
```

### 4.4 错误处理策略

#### 错误分类和处理

| 错误类型 | 触发场景 | 处理策略 | 用户提示 |
|---------|---------|---------|---------|
| 用户不存在 | API 返回 404 | 直接返回 | "未找到用户 {username}" |
| API 限流 | 429 状态码 | 等待后重试（3次）| "服务繁忙，请稍后再试" |
| 网络超时 | 请求超时 | 重试机制 | "网络连接超时，请稍后再试" |
| 数据解析错误 | JSON 解析失败 | 记录日志，返回错误 | "数据解析失败，请联系管理员" |
| 参数错误 | 用户输入非法 | 参数验证 | "参数错误：{错误信息}" |
| 渲染失败 | 图像生成异常 | 降级为文本 | 文本格式返回数据 |
| 缓存故障 | Redis 连接失败 | 降级为直接请求 | 透明处理，不提示 |

#### 降级策略
- 图片渲染失败 → 使用文本格式返回
- 缓存不可用 → 直接调用 API
- API 完全不可用 → 返回友好的错误提示和联系方式

#### 日志记录规范
| 日志级别 | 记录内容 | 示例 |
|---------|---------|------|
| DEBUG | 详细的执行流程 | "缓存命中: tetr:user:folx" |
| INFO | 正常的业务操作 | "用户查询: folx, 耗时: 120ms" |
| WARNING | 可恢复的异常 | "API 请求失败，重试中 (1/3)" |
| ERROR | 严重错误 | "图像渲染失败: {异常信息}" |
| CRITICAL | 系统级错误 | "API 客户端初始化失败" |

## 五、性能优化设计

### 5.1 缓存优化

#### 缓存预热机制
- 插件启动时预加载热门用户数据
- 定期刷新排行榜前 100 名数据
- 后台异步更新，不阻塞用户请求

#### 缓存更新策略
- 被动更新：缓存过期时重新请求
- 主动更新：检测到数据变化时立即更新
- 批量更新：合并多个用户的查询请求

### 5.2 图像渲染优化

#### 资源复用
- 背景模板预生成，仅动态填充数据
- 字体对象单例模式，避免重复加载
- 图标缓存，减少重复绘制
- 背景素材懒加载，首次使用后缓存
- 渐变图层预计算，存储为图片资源
- 效果滤镜结果缓存（相同参数复用）

#### 异步渲染
- 图像生成使用独立线程池
- 不阻塞主事件循环
- 支持并发渲染多张卡片

#### 输出优化
- 压缩图片大小（质量 85%，适配聊天场景）
- 支持 WebP 格式（体积更小）
- 智能调整分辨率（移动端降低分辨率）

### 5.3 API 请求优化

#### 请求合并
- 短时间内相同的请求只发送一次
- 使用请求锁机制避免重复调用

#### 连接池管理
- 复用 HTTP 连接
- 设置合理的连接池大小（10-20 个连接）
- 使用 Keep-Alive 保持连接

#### 批量查询
- 排行榜一次性获取多条数据
- 用户对比功能并行请求两个用户数据

### 5.4 内存管理

#### 内存限制
- 缓存数据总量不超过 100MB
- 使用 LRU 策略淘汰旧数据
- 定期清理过期缓存

#### 资源释放
- 图片生成后及时释放内存
- 大对象使用完毕后手动释放
- 定期执行垃圾回收

## 六、配置管理设计

### 6.1 插件配置文件

**配置文件位置**：`data/tetrio_config.yaml`

**配置项定义**：
```yaml
api:
  base_url: "https://ch.tetr.io/api"
  timeout: 10
  retry_times: 3
  user_agent: "AstrBot-TETRIO-Plugin/1.0"

cache:
  enabled: true
  user_info_ttl: 300        # 5分钟
  summary_ttl: 300          # 5分钟
  leaderboard_ttl: 600      # 10分钟
  server_stats_ttl: 60      # 1分钟
  max_memory_mb: 100

render:
  image_format: "png"       # png/webp
  image_quality: 85
  default_width: 800
  enable_cache: true
  font_path: "assets/fonts"
  icon_path: "assets/icons"

features:
  enable_trend: true        # 启用趋势图功能
  enable_compare: true      # 启用对比功能
  enable_achievements: true # 启用成就功能
  default_leaderboard_limit: 10
  max_leaderboard_limit: 25

display:
  show_avatar: true
  show_banner: true
  show_badges: true
  show_connections: true
  language: "zh_CN"         # 显示语言
```

### 6.2 用户偏好设置

**存储位置**：`data/user_preferences.json`

**偏好项**：
| 偏好项 | 类型 | 说明 | 默认值 |
|--------|------|------|--------|
| default_mode | str | 默认查询模式 | "user" |
| image_output | bool | 是否输出图片 | true |
| auto_refresh | bool | 自动刷新缓存 | false |
| language | str | 显示语言 | "zh_CN" |

### 6.3 管理员指令

| 指令 | 功能 | 权限要求 |
|------|------|---------|
| `/tetr admin reload` | 重载插件配置 | 管理员 |
| `/tetr admin cache clear` | 清空缓存 | 管理员 |
| `/tetr admin cache stats` | 查看缓存统计 | 管理员 |
| `/tetr admin status` | 查看插件状态 | 管理员 |

## 七、国际化设计

### 7.1 多语言支持

#### 支持语言
- 简体中文（zh_CN）- 默认
- 繁体中文（zh_TW）
- 英语（en_US）
- 日语（ja_JP）

#### 翻译文件结构
**文件位置**：`locales/{lang_code}.json`

**翻译键值示例**：
```json
{
  "command.user.not_found": "未找到用户 {username}",
  "command.user.success": "成功查询用户 {username}",
  "mode.league": "TETRA LEAGUE",
  "mode.40l": "40 LINES",
  "stat.xp": "经验值",
  "stat.gametime": "游戏时长",
  "rank.global": "全球排名",
  "rank.local": "本地排名"
}
```

### 7.2 时区处理
- 时间戳统一使用 UTC
- 显示时转换为用户时区（根据配置）
- 支持多种日期格式

## 八、安全性设计

### 8.1 输入验证
- 所有用户输入必须经过验证
- 防止 SQL 注入（虽然不使用数据库）
- 防止命令注入
- 限制输入长度

### 8.2 API 安全
- 使用 HTTPS 协议
- 验证 SSL 证书
- 设置请求超时
- 限制请求频率（避免被封禁）

### 8.3 数据隐私
- 不存储用户敏感信息
- 缓存数据仅包含公开信息
- 遵守 TETR.IO ToS

### 8.4 错误信息安全
- 不向用户暴露内部错误详情
- 敏感信息仅记录在日志中
- 日志文件访问权限控制

## 九、测试策略设计

### 9.1 单元测试

#### 测试范围
| 组件 | 测试内容 | 覆盖率目标 |
|------|---------|-----------|
| API Client | API 调用、错误处理 | 90% |
| Cache Manager | 缓存读写、过期处理 | 90% |
| Data Models | 数据验证、转换 | 95% |
| Command Router | 指令解析、路由 | 90% |
| Image Renderer | 模板渲染、元素绘制 | 80% |

#### Mock 策略
- Mock TETR.IO API 响应
- Mock 缓存系统
- Mock 图像生成（验证调用参数）

### 9.2 集成测试

#### 测试场景
| 场景 | 描述 | 验证点 |
|------|------|--------|
| 用户查询流程 | 从指令输入到图片输出 | 完整流程无错误 |
| 缓存机制 | 验证缓存命中和过期 | 缓存正确工作 |
| 错误处理 | 模拟 API 错误 | 降级策略生效 |
| 并发请求 | 同时处理多个查询 | 无数据竞争 |

### 9.3 性能测试

#### 测试指标
| 指标 | 目标值 | 测试方法 |
|------|--------|---------|
| 单次查询延迟 | < 2 秒 | 压力测试 |
| 缓存命中率 | > 80% | 日志分析 |
| 并发处理能力 | 50 QPS | 负载测试 |
| 内存占用 | < 200 MB | 监控统计 |

### 9.4 用户验收测试

#### 测试清单
- [ ] 所有指令能正常执行
- [ ] 图片显示美观，符合设计规范
- [ ] 错误提示友好、准确
- [ ] 响应速度快（用户感知 < 3秒）
- [ ] 多平台兼容（QQ、Telegram等）

## 十、部署和运维设计

### 10.1 依赖管理

**requirements.txt 内容**：
```
aiohttp>=3.9.0
Pillow>=10.0.0
pyyaml>=6.0
aiocache>=0.12.0
```

### 10.2 目录结构

```
astrbot_plugin_tetrio/
├── main.py                 # 插件入口
├── metadata.yaml           # 插件元数据
├── requirements.txt        # 依赖列表
├── logo.png               # 插件图标
├── README.md              # 说明文档
├── config/
│   └── default_config.yaml # 默认配置
├── src/
│   ├── api/
│   │   ├── client.py      # API 客户端
│   │   └── models.py      # 数据模型
│   ├── cache/
│   │   └── manager.py     # 缓存管理器
│   ├── render/
│   │   ├── renderer.py    # 图像渲染器
│   │   ├── templates.py   # 渲染模板
│   │   ├── effects.py     # 视觉效果处理器
│   │   ├── background.py  # 背景生成器
│   │   └── compositor.py  # 图层合成器
│   ├── commands/
│   │   ├── user.py        # 用户查询指令
│   │   ├── leaderboard.py # 排行榜指令
│   │   └── stats.py       # 统计指令
│   └── utils/
│       ├── validators.py  # 验证工具
│       ├── formatters.py  # 格式化工具
│       └── image_tools.py # 图像处理工具
├── assets/
│   ├── fonts/             # 字体文件
│   │   ├── NotoSansSC-Regular.ttf  # 思源黑体（中文）
│   │   ├── NotoSansSC-Bold.ttf     # 思源黑体粗体
│   │   ├── RobotoMono-Regular.ttf  # 等宽字体（数字）
│   │   └── Inter-Bold.ttf          # 标题字体
│   ├── icons/             # 图标资源
│   │   ├── ranks/         # 段位图标
│   │   ├── modes/         # 游戏模式图标
│   │   ├── stats/         # 统计图标
│   │   └── decorations/   # 装饰图标
│   ├── backgrounds/       # 背景素材库
│   │   ├── base/          # 基础纹理
│   │   │   ├── carbon_fiber.png
│   │   │   ├── hexagon_grid.png
│   │   │   ├── tech_lines.png
│   │   │   ├── circuit_pattern.png
│   │   │   └── noise_texture.png
│   │   ├── gradients/     # 预生成渐变
│   │   │   ├── purple_gradient.png  # X/U 段位
│   │   │   ├── red_gradient.png     # SS/S+ 段位
│   │   │   ├── orange_gradient.png  # S 段位
│   │   │   └── blue_gradient.png    # 通用蓝色
│   │   ├── effects/       # 光效素材
│   │   │   ├── radial_glow.png      # 径向光晕
│   │   │   ├── edge_light.png       # 边缘光
│   │   │   ├── sparkle.png          # 星光闪烁
│   │   │   └── lens_flare.png       # 镜头光晕
│   │   ├── patterns/      # 装饰图案
│   │   │   ├── tetromino_watermark.png  # 方块水印
│   │   │   ├── grid_overlay.png         # 网格叠加层
│   │   │   └── corner_decorations.png   # 角落装饰
│   │   └── README.md      # 素材来源说明
│   └── templates/         # 卡片模板配置
│       ├── user_card.json
│       ├── league_card.json
│       ├── sprint_card.json
│       └── leaderboard.json
└── locales/
    ├── zh_CN.json         # 简体中文
    ├── zh_TW.json         # 繁体中文
    └── en_US.json         # 英语
```

### 10.3 监控和日志

#### 日志文件
- 位置：`data/logs/tetrio.log`
- 轮转：每日轮转，保留 7 天
- 格式：`[时间] [级别] [组件] 消息内容`

#### 监控指标
| 指标 | 说明 | 告警阈值 |
|------|------|---------|
| API 成功率 | API 调用成功的比例 | < 95% |
| 平均响应时间 | 指令处理平均耗时 | > 3秒 |
| 缓存命中率 | 缓存命中的比例 | < 70% |
| 错误数量 | 每小时错误次数 | > 10次 |

### 10.4 升级和维护

#### 版本管理
- 语义化版本：MAJOR.MINOR.PATCH
- CHANGELOG.md 记录版本变更
- 兼容性说明

#### 数据迁移
- 配置文件升级时自动迁移
- 缓存格式变更时清空重建
- 保留旧版本配置备份

#### 灰度发布
- 先在测试群组部署
- 观察 24 小时无问题后全量发布
- 支持快速回滚

## 十一、扩展性设计

### 11.1 插件系统
- 支持自定义渲染模板
- 支持第三方数据源（如 osk 的第三方 API）
- 开放部分接口供其他插件调用

### 11.2 未来功能规划
- 数据分析和建议（AI 辅助）
- 社区排行榜（群组内排名）
- 定时推送（个人记录更新通知）
- 比赛数据追踪
- 回放解析和展示

### 11.3 接口预留
- 预留用户数据导出接口
- 预留 Webhook 接口（接收 TETR.IO 事件）
- 预留自定义查询接口

## 十二、文档和支持

### 12.1 用户文档

#### README.md 内容
- 插件介绍和功能列表
- 安装和配置指南
- 指令使用说明（带示例）
- 常见问题解答
- 更新日志

#### 使用示例
```markdown
## 使用示例

### 查询用户信息
/tetr user folx
/tetr u folx

### 查询 TETRA LEAGUE 数据
/tetr league folx

### 查看排行榜
/tetr lb league 10
/tetr leaderboard 40l 20

### 搜索用户
/tetr search folx
```

### 12.2 开发文档

#### API 文档
- 所有公开接口的说明
- 参数和返回值定义
- 调用示例

#### 架构文档
- 系统架构图
- 组件交互说明
- 数据流图

### 12.3 支持渠道
- GitHub Issues：Bug 报告和功能建议
- QQ 群：用户交流和支持
- Wiki：详细的使用教程

## 十三、合规性设计

### 13.1 遵守 TETR.IO ToS
- 不滥用 API（遵守频率限制）
- 不用于商业用途（除非获得授权）
- 尊重用户隐私设置
- 标注数据来源

### 13.2 开源协议
- 使用 AGPL-3.0 许可证（与模板保持一致）
- 标注第三方依赖的许可证
- 尊重字体和图标的版权

### 13.3 免责声明
- 插件为非官方项目
- 数据准确性由 TETR.IO API 保证
- 不对数据丢失或错误负责

## 十四、实施路线图

### 14.1 开发阶段

#### Phase 1: 基础功能（2-3 周）
- [ ] 搭建项目框架
- [ ] 实现 API 客户端
- [ ] 实现基础指令（user、league、40l、blitz）
- [ ] 实现简单的文本输出

#### Phase 2: 图像渲染（2 周）
- [ ] 设计渲染模板
- [ ] 实现图像渲染器
- [ ] 实现用户信息卡片
- [ ] 实现游戏模式卡片

#### Phase 3: 高级功能（1-2 周）
- [ ] 实现排行榜功能
- [ ] 实现搜索功能
- [ ] 实现缓存系统
- [ ] 实现错误处理

#### Phase 4: 优化和测试（1 周）
- [ ] 性能优化
- [ ] 单元测试
- [ ] 集成测试
- [ ] 文档编写

#### Phase 5: 扩展功能（可选，1-2 周）
- [ ] 用户对比功能
- [ ] 数据趋势图
- [ ] 成就系统
- [ ] 多语言支持

### 14.2 发布计划

#### Beta 版本（v0.9.0）
- 核心功能完整
- 在小范围内测试
- 收集用户反馈

#### 正式版本（v1.0.0）
- 修复已知 Bug
- 优化用户体验
- 发布到插件市场

#### 后续版本
- v1.1.0: 添加趋势图和对比功能
- v1.2.0: 多语言支持
- v1.3.0: 性能优化和新功能

## 十五、风险评估

### 15.1 技术风险

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|---------|
| API 变更 | 高 | 中 | 版本检测、快速适配、降级策略 |
| 依赖库不兼容 | 中 | 低 | 锁定版本、充分测试 |
| 性能瓶颈 | 中 | 中 | 性能测试、优化方案 |
| 内存泄漏 | 高 | 低 | 代码审查、内存监控 |

### 15.2 运营风险

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|---------|
| API 被限流/封禁 | 高 | 中 | 遵守规则、友好的 User-Agent、请求限制 |
| 用户滥用 | 中 | 中 | 频率限制、管理员控制 |
| 法律合规问题 | 高 | 低 | 遵守 ToS、咨询法律意见 |

### 15.3 用户体验风险

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|---------|
| 响应速度慢 | 中 | 中 | 缓存优化、异步处理 |
| 图片加载失败 | 中 | 低 | 降级为文本、重试机制 |
| 跨平台兼容性 | 中 | 中 | 多平台测试、适配 |

---

## 附录

### 附录 A：TETR.IO API 端点清单

| 端点 | 方法 | 用途 | 缓存时间 |
|------|------|------|---------|
| /general/stats | GET | 服务器统计 | 60s |
| /users/:user | GET | 用户信息 | 5min |
| /users/:user/summaries/league | GET | TETRA LEAGUE 数据 | 5min |
| /users/:user/summaries/40l | GET | 40 LINES 数据 | 5min |
| /users/:user/summaries/blitz | GET | BLITZ 数据 | 5min |
| /users/:user/summaries/zenith | GET | QUICK PLAY 数据 | 5min |
| /users/:user/summaries/zen | GET | ZEN 数据 | 5min |
| /users/search/:query | GET | 搜索用户 | - |
| /users/by/:leaderboard | GET | 排行榜 | - |
| /labs/leagueflow/:user | GET | League 数据流 | 5min |

### 附录 B：段位系统参考

| 段位代码 | 段位名称 | TR 范围 | 颜色 |
|---------|---------|---------|------|
| x | X Rank | 25000+ | 紫色 |
| u | U Rank | 23000-25000 | 红紫 |
| ss | SS Rank | 21000-23000 | 红色 |
| s+ | S+ Rank | 20000-21000 | 橙红 |
| s | S Rank | 17500-20000 | 橙色 |
| s- | S- Rank | 15000-17500 | 黄橙 |
| a+ | A+ Rank | 12500-15000 | 黄色 |
| a | A Rank | 10000-12500 | 绿黄 |
| a- | A- Rank | 7500-10000 | 绿色 |
| b+ | B+ Rank | 5000-7500 | 青绿 |
| b | B Rank | 2500-5000 | 青色 |
| b- | B- Rank | 0-2500 | 蓝色 |
| c+ | C+ Rank | - | 蓝色 |
| c | C Rank | - | 蓝色 |
| c- | C- Rank | - | 蓝色 |
| d+ | D+ Rank | - | 灰蓝 |
| d | D Rank | - | 灰色 |
| z | Unranked | - | 灰色 |

### 附录 C：性能基准

| 操作 | 目标时间 | 备注 |
|------|---------|------|
| API 单次请求 | < 500ms | 不含网络延迟 |
| 缓存读取 | < 10ms | 内存缓存 |
| 图片渲染（用户卡片）| < 1s | 800x1200 分辨率 |
| 图片渲染（排行榜）| < 800ms | 800x600 分辨率 |
| 完整查询流程 | < 2s | 从指令到输出 |

### 附录 D：配色参考代码

```
背景色：
- 主背景: #0F0F14
- 次级背景: #1A1A24
- 三级背景: #242430

文字色：
- 主文字: #FFFFFF
- 次文字: #9B9BA5
- 禁用: #5A5A66

强调色：
- 主强调: #6366F1
- 成功: #10B981
- 警告: #F59E0B
- 错误: #EF4444

段位色（渐变）：
- X: linear-gradient(135deg, #A855F7, #8B5CF6)
- U: linear-gradient(135deg, #EC4899, #A855F7)
- SS: #EF4444
- S+: #F97316
- S: #F59E0B
```

---

## 十六、图像渲染高级技术详细设计

### 16.1 背景素材获取和使用指南

#### 推荐素材资源库

**高质量免费素材网站**：

1. **Unsplash** (https://unsplash.com)
   - 搜索关键词：
     * "dark abstract background"
     * "technology pattern"
     * "geometric dark"
     * "cyberpunk texture"
     * "neon gradient"
   - 许可：Unsplash License（免费商用）
   - 下载尺寸：1920x1080 或更高

2. **Pexels** (https://www.pexels.com)
   - 搜索关键词：
     * "dark background"
     * "abstract wallpaper"
     * "digital technology"
     * "futuristic background"
   - 许可：Pexels License（免费商用）

3. **Subtle Patterns** (https://www.toptal.com/designers/subtlepatterns/)
   - 类型：微妙纹理、可平铺
   - 推荐图案：
     * Carbon Fiber
     * Hexagons
     * Circuit Board
     * Dark Geometric
   - 许可：CC BY-SA 3.0

4. **Pixabay** (https://pixabay.com)
   - 搜索关键词：
     * "light effect"
     * "glow background"
     * "particle effect"
     * "lens flare"
   - 许可：Pixabay License（免费商用）

5. **Hero Patterns** (https://heropatterns.com)
   - 类型：SVG 背景图案（可转 PNG）
   - 支持自定义颜色
   - 免费使用

6. **Freepik** (https://www.freepik.com)
   - 搜索："futuristic background free"
   - 注意：免费版需要归属标注
   - 可获取矢量图

#### 具体素材需求清单

| 素材名称 | 推荐来源 | 搜索关键词 | 尺寸要求 | 用途 |
|---------|---------|------------|----------|------|
| 碳纤维纹理 | Subtle Patterns | "carbon fiber" | 512x512 (tileable) | 卡片基底 |
| 六角网格 | Hero Patterns | "hexagons" | SVG | 科技感背景 |
| 深色抽象 | Unsplash | "dark abstract" | 1920x1080 | 主背景 |
| 光效素材 | Pixabay | "light effect" | 1920x1080 | 光晕叠加 |
| 电路板 | Subtle Patterns | "circuit" | 512x512 | 科技风 |
| 霓虹渐变 | 自行生成 | - | 任意 | 段位背景 |
| 方块图案 | 自绘/Freepik | "tetris blocks" | 矢量 | 主题装饰 |
| 星光粒子 | Pixabay | "sparkle" | 512x512 | 成就/高分 |

#### 素材处理流程

**下载后处理步骤**：

1. **尺寸调整**
   - 使用 Pillow 调整到目标尺寸（如 1200x800）
   - 保持高分辨率以备缩放

2. **颜色调整**
   - 降低亮度（如果太亮）
   - 调整对比度以适配深色主题
   - 添加主题色覆盖层

3. **模糊处理**
   - 轻微高斯模糊（radius=5-10）减弱细节
   - 避免喧宾夺主

4. **透明度调整**
   - 设置 10-30% 透明度
   - 作为纹理层使用

5. **平铺处理（如需）**
   - 确保纹理可无缝平铺
   - 使用 offset wrap 技术

### 16.2 程序化背景生成器

#### 渐变背景生成器设计

**功能接口设计**：

函数名：generate_gradient_background  
输入参数：
- width: int (宽度)
- height: int (高度)
- color1: str (HEX 颜色 1)
- color2: str (HEX 颜色 2)
- color3: str (HEX 颜色 3, 可选)
- direction: str ("horizontal", "vertical", "diagonal", "radial")
- noise_level: float (0.0-1.0, 噪点强度)

输出：PIL.Image 对象

**生成算法**：

1. **线性渐变**
   - 逐像素计算颜色插值
   - 支持任意角度（0-360度）

2. **径向渐变**
   - 计算每个像素到中心的距离
   - 根据距离进行颜色插值

3. **噪点叠加**
   - Perlin Noise 算法生成自然噪点
   - 与渐变混合（加权叠加）

#### 几何图案生成器设计

**六角网格生成器**：

函数名：generate_hexagon_grid  
输入参数：
- width: int
- height: int
- hex_size: int (六角形半径，默认 30)
- line_width: int (线宽，默认 2)
- color: str (HEX 颜色)
- opacity: float (0.0-1.0)

输出：带 Alpha 通道的 PNG 图层

**方块网格生成器**：

函数名：generate_tetris_grid  
输入参数：
- width: int
- height: int
- block_size: int (方块大小，默认 40)
- spacing: int (间隔，默认 2)
- colors: List[str] (TETR.IO 经典 7 色)
- random_layout: bool (随机布局)
- opacity: float

输出：透明 PNG

**点阵图案生成器**：

函数名：generate_dot_pattern  
输入参数：
- width: int
- height: int
- dot_size: int (点半径，默认 3)
- spacing_x: int (X 轴间距)
- spacing_y: int (Y 轴间距)
- color: str
- opacity: float

输出：透明 PNG

### 16.3 高级光效实现

#### 外发光效果

**实现原理**：
1. 复制原始图层
2. 应用高斯模糊（radius = 10-30px）
3. 调整亮度和透明度
4. 叠加到原图层下方

**参数控制**：

函数名：add_glow_effect  
输入：
- image: PIL.Image (原图)
- glow_color: str (HEX, 可选，默认使用图像主色)
- radius: int (发光半径 10-50)
- intensity: float (强度 0.0-1.0)

输出：带发光效果的图像

#### 边缘光效果

**实现原理**：
1. 检测图层边缘（如 Alpha 通道边界）
2. 沿着边缘绘制发光线条
3. 应用模糊和渐变
4. 叠加到原图

**适用场景**：
- 卡片边框
- 段位徽章
- 按钮高光

#### 文字发光效果

**实现方案**：
1. 先绘制模糊的发光层（较大字号）
2. 再绘制正常文字层
3. 最后绘制高光层（较亮颜色）

**分层结构**：
- 底层：发光（主题色，模糊 10px）
- 中层：主文字（白色/浅色）
- 顶层：高光（亮白色，仅上部）

### 16.4 具体渲染实侏

#### 用户信息卡片渲染流程

**第一步：背景层构建**
1. 加载碳纤维纹理 (base/carbon_fiber.png)
2. 调整到卡片尺寸 (800x1200)
3. 设置亮度 -30%
4. 添加微妙模糊 (radius=3)

**第二步：横幅区域** (顶部 300px 高度)
1. 如果有用户横幅：
   - 下载并缓存
   - 裁剪为 800x300
   - 应用渐变遮罩（底部淡出）
2. 否则：
   - 生成根据段位的渐变背景
   - X rank: 紫色霓虹渐变
   - U rank: 紫红渐变
   - SS/S+: 红橙渐变
3. 添加微妙粒子效果

**第三步：头像区域**
1. 下载用户头像 (tetr.io/user-content/avatars/)
2. 裁剪为圆形 (120x120)
3. 添加段位色边框 (5px, 段位对应色)
4. 添加外发光 (radius=15, 段位色 50%)
5. 放置在 (40, 220) 位置

**第四步：用户名和徽章**
1. 绘制用户名 (180, 240)
   - 字体：Inter-Bold, 32px
   - 颜色：#FFFFFF
   - 添加文字阴影 (2px offset, #000000 50%)
2. 绘制徽章行 (180, 280)
   - 每个徽章 32x32
   - 水平间隔 8px
   - 最多显示 6 个

**第五步：统计数据卡片**
1. 创建半透明卡片背景
   - 尺寸：760x150
   - 颜色：#1A1A24, 90% opacity
   - 圆角：12px
   - 边框：1px #2A2A35
2. 分为 3 列布局 (XP | 游戏时长 | 在线游戏)
3. 每列绘制：
   - 图标 (48x48, 顶部)
   - 标签 (#9B9BA5, 14px)
   - 数值 (#FFFFFF, RobotoMono-Regular, 24px)

**最终合成**：
1. 合并所有图层
2. 应用全局锅度调整 (+5% sharpness)
3. 压缩为 WebP 或 PNG (quality=85)
4. 输出为 Base64 或保存文件

---

**文档版本**: v1.1  
**最后更新**: 2024-01-XX  
**维护者**: AstrBot TETRIO Plugin Team  
